import java.util.*;

public class BankBranch {
    private String branchId;
    private String branchName;
    private List<Customer> customers = new ArrayList<>();

    public BankBranch(String id, String name) {
        this.branchId = id;
        this.branchName = name;
        System.out.println("✅ Branch Created: " + branchName + " [Branch ID: " + branchId + "]");
    }

    public void addCustomer(Customer c) {
        customers.add(c);
        System.out.println("✅ Customer added: " + c.getName());
    }

    public Customer findCustomerById(String id) {
        for (Customer c : customers) {
            if (c.getCustomerId().equals(id)) return c;
        }
        return null;
    }

    public void listAllCustomers() {
        for (Customer c : customers) {
            System.out.println(" - " + c.getName() + " [" + c.getCustomerId() + "]");
        }
    }
}