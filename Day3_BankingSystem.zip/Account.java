import java.util.*;

public abstract class Account implements BankOperations {
    protected String accountNumber;
    protected double balance;
    protected List<String> transactionHistory = new ArrayList<>();

    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        addTransaction("Account opened with balance: ₹" + initialBalance);
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);

    public void transfer(Account target, double amount) {
        if (this.balance >= amount) {
            this.withdraw(amount);
            target.deposit(amount);
            addTransaction("Transferred ₹" + amount + " to Account " + target.accountNumber);
        } else {
            System.out.println("❌ Insufficient balance for transfer.");
        }
    }

    public double checkBalance() {
        return balance;
    }

    protected void addTransaction(String info) {
        transactionHistory.add(info);
    }

    public void showTransactionHistory() {
        System.out.println("📋 Transaction History for Account: " + accountNumber);
        for (String entry : transactionHistory) {
            System.out.println(" - " + entry);
        }
    }
}