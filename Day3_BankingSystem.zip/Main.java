public class Main {
    public static void main(String[] args) {
        BankBranch branch = new BankBranch("B001", "Main Branch");

        Customer c1 = new Customer("C001", "Alice");
        branch.addCustomer(c1);

        SavingsAccount sAcc = new SavingsAccount("S001", 5000);
        CurrentAccount cAcc = new CurrentAccount("C001", 2000);

        c1.addAccount(sAcc);
        c1.addAccount(cAcc);

        sAcc.deposit(2000);
        System.out.println("💰 Savings Balance: ₹" + sAcc.checkBalance());

        cAcc.withdraw(2500);
        System.out.println("💰 Current Balance: ₹" + cAcc.checkBalance());

        sAcc.transfer(cAcc, 1000);
        System.out.println("💰 Savings Balance: ₹" + sAcc.checkBalance());
        System.out.println("💰 Current Balance: ₹" + cAcc.checkBalance());

        sAcc.showTransactionHistory();
        cAcc.showTransactionHistory();
    }
}